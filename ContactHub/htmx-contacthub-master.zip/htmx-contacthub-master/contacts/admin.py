from django.contrib import admin
from contacts.models import User


# Register your models here.
admin.site.register(User)